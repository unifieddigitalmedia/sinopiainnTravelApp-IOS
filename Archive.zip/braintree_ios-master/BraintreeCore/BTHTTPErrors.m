#import "BTHTTPErrors.h"

NSString * const BTHTTPErrorDomain = @"com.braintreepayments.BTHTTPErrorDomain";

NSString * const BTHTTPURLResponseKey = @"com.braintreepayments.BTHTTPURLResponseKey";

NSString * const BTHTTPJSONResponseBodyKey = @"com.braintreepayments.BTHTTPJSONResponseBodyKey";
