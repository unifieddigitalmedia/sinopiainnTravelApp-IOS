#import <UIKit/UIKit.h>
#import "BTDropInBaseViewController.h"

/// @class Pending implementation
@interface BTVaultManagementViewController : BTDropInBaseViewController

@end
