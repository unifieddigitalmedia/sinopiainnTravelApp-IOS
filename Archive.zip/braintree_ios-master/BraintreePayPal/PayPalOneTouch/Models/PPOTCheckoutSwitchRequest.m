//
//  PPOTCheckoutSwitchRequest.m
//  PayPalOneTouch
//
//  Copyright © 2015 PayPal, Inc. All rights reserved.
//

#import "PPOTCheckoutSwitchRequest.h"

@implementation PPOTCheckoutSwitchRequest

@end
