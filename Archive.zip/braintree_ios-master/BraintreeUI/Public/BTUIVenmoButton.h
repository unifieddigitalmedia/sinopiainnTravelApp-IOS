#import <UIKit/UIKit.h>

@class BTUI;

@interface BTUIVenmoButton : UIControl

@property (nonatomic, strong) BTUI *theme;

@end
