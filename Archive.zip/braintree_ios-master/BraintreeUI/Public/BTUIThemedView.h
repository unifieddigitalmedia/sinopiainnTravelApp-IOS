#import <UIKit/UIKit.h>
#import "BTUI.h"

@interface BTUIThemedView : UIView
@property (nonatomic, strong) BTUI *theme;
@end
