#import "BTDropInViewController.h"
#import "BTDropInContentView.h"

@interface BTDropInViewController ()

@property (nonatomic, strong) BTDropInContentView *dropInContentView;

- (BTDropInViewController *)addPaymentMethodDropInViewController;

@end
