#import "BTUICardVectorArtView.h"

@interface BTUIAmExVectorArtView : BTUICardVectorArtView

@end
