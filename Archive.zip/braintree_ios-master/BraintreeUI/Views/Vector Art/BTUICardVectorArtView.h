#import "BTUIVectorArtView.h"

@interface BTUICardVectorArtView : BTUIVectorArtView

@property (nonatomic, strong) UIColor *highlightColor;

@end
