#import "BTUICardVectorArtView.h"

@interface BTUIVisaVectorArtView : BTUICardVectorArtView

@end
