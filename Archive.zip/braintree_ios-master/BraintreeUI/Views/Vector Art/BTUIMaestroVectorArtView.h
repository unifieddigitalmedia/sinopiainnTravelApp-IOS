#import "BTUICardVectorArtView.h"

@interface BTUIMaestroVectorArtView : BTUICardVectorArtView

@end
