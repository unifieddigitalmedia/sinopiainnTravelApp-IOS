#import "BTUICardVectorArtView.h"

@interface BTUIUnknownCardVectorArtView : BTUICardVectorArtView

@end
