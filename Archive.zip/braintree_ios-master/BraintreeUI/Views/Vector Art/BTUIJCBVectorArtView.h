#import "BTUICardVectorArtView.h"

@interface BTUIJCBVectorArtView : BTUICardVectorArtView

@end
