#import "BTUICardVectorArtView.h"

@interface BTUIPayPalMonogramCardView : BTUICardVectorArtView

@end
