#import "BTUICardVectorArtView.h"

@interface BTUIDinersClubVectorArtView : BTUICardVectorArtView

@end
