#import "BTUICardVectorArtView.h"

@interface BTUIVenmoMonogramCardView : BTUICardVectorArtView

@end
