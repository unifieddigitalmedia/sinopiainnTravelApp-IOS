#import "BTUIVectorArtView.h"

@interface BTUIVenmoWordmarkVectorArtView : BTUIVectorArtView

@property (nonatomic, strong) UIColor *color;

@end
