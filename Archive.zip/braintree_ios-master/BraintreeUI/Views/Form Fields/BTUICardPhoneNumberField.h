//
//  BTUICardPhoneNumberField.h
//  Braintree
//
//  Created by Shin, Richard on 3/3/16.
//
//

#import "BTUIFormField.h"

@interface BTUICardPhoneNumberField : BTUIFormField

@property (nonatomic, copy) NSString *phoneNumber;

@end
