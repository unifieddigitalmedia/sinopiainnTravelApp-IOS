#import "BTUIPayPalButton.h"

@interface BTUIPayPalCompactButton : BTUIPayPalButton

@end
