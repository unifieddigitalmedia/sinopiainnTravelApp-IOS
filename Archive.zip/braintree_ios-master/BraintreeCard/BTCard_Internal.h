#import "BTCard.h"
#import "BTJSON.h"

@interface BTCard ()

/// @name Parameters

- (NSDictionary *)parameters;

@end
