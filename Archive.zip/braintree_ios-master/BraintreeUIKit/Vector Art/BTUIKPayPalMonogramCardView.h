#import "BTUIKCardVectorArtView.h"

@interface BTUIKPayPalMonogramCardView : BTUIKCardVectorArtView

@end
