#import "BTUIKCardVectorArtView.h"

@interface BTUIKVenmoMonogramCardView : BTUIKCardVectorArtView

@end
