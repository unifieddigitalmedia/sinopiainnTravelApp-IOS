#import "BTUIKVectorArtView.h"

@interface BTUIKCardVectorArtView : BTUIKVectorArtView

@property (nonatomic, strong) UIColor *highlightColor;

@end
