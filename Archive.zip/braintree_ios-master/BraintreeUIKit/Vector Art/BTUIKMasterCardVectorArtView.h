#import "BTUIKCardVectorArtView.h"

@interface BTUIKMasterCardVectorArtView : BTUIKCardVectorArtView

@end
