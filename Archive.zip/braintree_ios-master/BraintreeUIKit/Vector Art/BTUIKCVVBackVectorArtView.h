#import "BTUIKCardVectorArtView.h"

@interface BTUIKCVVBackVectorArtView : BTUIKCardVectorArtView

@end
