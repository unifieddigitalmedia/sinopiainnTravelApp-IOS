#import "BTUIKCardVectorArtView.h"

@interface BTUIKMaestroVectorArtView : BTUIKCardVectorArtView

@end
