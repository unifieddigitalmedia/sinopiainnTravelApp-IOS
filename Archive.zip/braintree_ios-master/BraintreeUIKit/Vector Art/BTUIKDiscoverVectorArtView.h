#import "BTUIKCardVectorArtView.h"

@interface BTUIKDiscoverVectorArtView : BTUIKCardVectorArtView

@end
