#import "BTUIKCardVectorArtView.h"

@interface BTUIKAmExVectorArtView : BTUIKCardVectorArtView

@end
