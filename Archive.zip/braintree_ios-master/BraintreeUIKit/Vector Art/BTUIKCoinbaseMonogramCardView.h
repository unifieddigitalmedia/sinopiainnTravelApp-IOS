#import "BTUIKCardVectorArtView.h"

@interface BTUIKCoinbaseMonogramCardView : BTUIKCardVectorArtView

@end
