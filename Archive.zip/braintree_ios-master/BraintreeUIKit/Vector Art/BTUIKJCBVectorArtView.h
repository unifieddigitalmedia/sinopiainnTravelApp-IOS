#import "BTUIKCardVectorArtView.h"

@interface BTUIKJCBVectorArtView : BTUIKCardVectorArtView

@end
