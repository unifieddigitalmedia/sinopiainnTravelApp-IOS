#import "BTUIKCardVectorArtView.h"

@interface BTUIKVisaVectorArtView : BTUIKCardVectorArtView

@end
