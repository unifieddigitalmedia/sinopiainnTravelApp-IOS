#import <UIKit/UIKit.h>

@interface BTUIKExpiryInputCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) UILabel* label;

- (NSInteger)getInteger;

@end
