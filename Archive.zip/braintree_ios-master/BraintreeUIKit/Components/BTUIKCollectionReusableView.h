#import <UIKit/UIKit.h>

@interface BTUIKCollectionReusableView : UICollectionReusableView

@property (nonatomic, strong) UILabel* label;

@end
