[The Braintree iOS SDK 3.x Card header files have moved here.](https://github.com/braintree/braintree_ios/tree/3.x/Braintree/API/@Public)

Note: Those header files are for an old version of our SDK. We recommend upgrading to [the latest version](https://github.com/braintree/braintree_ios/) at your convenience.

