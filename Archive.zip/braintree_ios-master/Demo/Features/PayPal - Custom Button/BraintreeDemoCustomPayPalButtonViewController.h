#import <Foundation/Foundation.h>

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoCustomPayPalButtonViewController : BraintreeDemoPaymentButtonBaseViewController

@end
