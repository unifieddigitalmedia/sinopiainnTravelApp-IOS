#import <UIKit/UIKit.h>

#import "BraintreeDemoBaseViewController.h"

@interface BraintreeDemoCardTokenizationViewController : BraintreeDemoBaseViewController
@end
