#import <Foundation/Foundation.h>

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoBTUIVenmoButtonViewController : BraintreeDemoPaymentButtonBaseViewController
@end
