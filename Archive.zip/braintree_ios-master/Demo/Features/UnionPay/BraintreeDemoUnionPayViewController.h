#import "BraintreeDemoBaseViewController.h"

@interface BraintreeDemoUnionPayViewController : BraintreeDemoBaseViewController

@end
