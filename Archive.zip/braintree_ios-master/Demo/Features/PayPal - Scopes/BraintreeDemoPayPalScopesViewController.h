@import Foundation;

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoPayPalScopesViewController : BraintreeDemoPaymentButtonBaseViewController
@end
