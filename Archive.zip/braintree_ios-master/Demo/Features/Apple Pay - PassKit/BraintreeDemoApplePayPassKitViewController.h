#import <Foundation/Foundation.h>

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoApplePayPassKitViewController : BraintreeDemoPaymentButtonBaseViewController
@end
