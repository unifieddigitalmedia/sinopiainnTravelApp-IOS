#import <Foundation/Foundation.h>

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoBTUIPayPalButtonViewController : BraintreeDemoPaymentButtonBaseViewController
@end
