#import <UIKit/UIKit.h>

#import "BraintreeDemoBaseViewController.h"

@interface BraintreeDemoDropInLegacyViewController : BraintreeDemoBaseViewController

@end
