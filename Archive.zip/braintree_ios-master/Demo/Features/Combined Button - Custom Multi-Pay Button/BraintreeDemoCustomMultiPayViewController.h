#import <Foundation/Foundation.h>

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoCustomMultiPayViewController : BraintreeDemoPaymentButtonBaseViewController
@end
