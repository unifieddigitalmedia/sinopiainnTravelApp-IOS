#import <UIKit/UIKit.h>

#import "BraintreeDemoBaseViewController.h"

@interface BraintreeDemoBTDataCollectorViewController : BraintreeDemoBaseViewController

@end
