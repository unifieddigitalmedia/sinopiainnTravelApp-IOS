#import <Foundation/Foundation.h>

#import "BraintreeDemoBaseViewController.h"
#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoBTPaymentButtonViewController : BraintreeDemoPaymentButtonBaseViewController

@end
