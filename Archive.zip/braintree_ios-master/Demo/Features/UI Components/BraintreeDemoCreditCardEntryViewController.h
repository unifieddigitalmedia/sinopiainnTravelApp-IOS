#import <UIKit/UIKit.h>
#import <BraintreeUI/BraintreeUI.h>

@interface BraintreeDemoCreditCardEntryViewController : UIViewController
@property (weak, nonatomic) IBOutlet BTUICardFormView *cardFormView;

@end
