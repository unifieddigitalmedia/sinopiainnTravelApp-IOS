#import <UIKit/UIKit.h>

@interface BraintreeDemoCardHintViewController : UIViewController

@end
