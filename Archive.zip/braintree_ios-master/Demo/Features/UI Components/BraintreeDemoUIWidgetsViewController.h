#import <UIKit/UIKit.h>

#import "BraintreeDemoBaseViewController.h"

@interface BraintreeDemoUIWidgetsViewController : BraintreeDemoBaseViewController

@end
