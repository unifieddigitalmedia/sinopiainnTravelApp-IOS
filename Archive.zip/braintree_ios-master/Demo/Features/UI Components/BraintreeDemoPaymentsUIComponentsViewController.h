#import <UIKit/UIKit.h>

@interface BraintreeDemoPaymentsUIComponentsViewController : UIViewController
@end
