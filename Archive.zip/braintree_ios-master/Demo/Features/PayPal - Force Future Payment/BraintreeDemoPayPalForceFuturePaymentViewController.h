#import <Foundation/Foundation.h>

#import "BraintreeDemoPaymentButtonBaseViewController.h"

@interface BraintreeDemoPayPalForceFuturePaymentViewController : BraintreeDemoPaymentButtonBaseViewController

@end
