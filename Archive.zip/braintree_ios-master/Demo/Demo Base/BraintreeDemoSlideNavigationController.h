#import "SlideNavigationController.h"

@interface BraintreeDemoSlideNavigationController : SlideNavigationController

@end
