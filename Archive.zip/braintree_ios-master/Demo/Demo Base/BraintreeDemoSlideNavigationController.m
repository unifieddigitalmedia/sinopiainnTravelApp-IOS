#import "BraintreeDemoSlideNavigationController.h"

@implementation BraintreeDemoSlideNavigationController

- (void)navigationController:(__unused UINavigationController *)navigationController
      willShowViewController:(__unused UIViewController *)viewController
                    animated:(__unused BOOL)animated
{}

@end
