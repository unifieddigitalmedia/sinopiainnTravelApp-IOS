#import <UIKit/UIKit.h>

@interface BraintreeDemoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
