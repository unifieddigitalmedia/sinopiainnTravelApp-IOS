#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double BraintreeDataCollectorVersionNumber;

FOUNDATION_EXPORT const unsigned char BraintreeDataCollectorVersionString[];

#import "BTDataCollector.h"

