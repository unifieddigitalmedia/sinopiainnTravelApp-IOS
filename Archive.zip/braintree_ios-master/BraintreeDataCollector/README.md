# Braintree Data Collector

Our `BraintreeDataCollector` provides a fraud solution powered by `BTDataCollector`, PayPal, and Kount.

See our [Advanced Fraud Tools - Client-Side Documentation](https://developers.braintreepayments.com/ios/guides/advanced-fraud-tools/client-side) for more information.
